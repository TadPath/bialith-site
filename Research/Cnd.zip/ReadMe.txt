Some Notes:

1. Bronchial Carcinoid VRML Model made using FATCAM.exe from www.bialith.com
2. A VRML Plug-In / Viewer required to view this model.
3. Double-click the file CndSm.wrl to begin (it takes a few moments to load so be patient).
4. This is a very low resolution model for ease of download and manipulation on small computers. It is possible to build much higher resolution models down to sub-cellular resolution in histology - depending on the quality of the original section images.

For further details or to download the FATCAM software visit www.bialith.com

PJT 20-08/2002
